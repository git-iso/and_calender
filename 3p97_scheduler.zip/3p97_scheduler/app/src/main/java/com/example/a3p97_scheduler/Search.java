package com.example.a3p97_scheduler;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

// Show all appointments on selected date
public class Search extends AppCompatActivity implements View.OnClickListener {

    //UI definitions
    PopupWindow popupWindow;
    TextView text_title, text_time, text_details;

    //Search definitions
    AppointmentAdaptor appointmentAdaptor;
    ListView listView;
    List<Appointment> listArr;
    ArrayList<String> arrayList;
    ArrayAdapter adapter;

    //Database definitions
    DB myDBHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        //DB assignment
        myDBHandler = new DB(this, null, null, 1);
        Intent intent = getIntent();
        String date = intent.getStringExtra("Date");


        //Show appointments
        listArr = myDBHandler.displayAppointments(date);

        arrayList = new ArrayList<>();

        for(int j=0 ; j<listArr.size() ; j++){

            arrayList.add(j+1 + ". " + listArr.get(j).getTime() + " " + listArr.get(j).getTitle() + " " + listArr.get(j).getDetails());


        }

        adapter = new ArrayAdapter<String>(this, R.layout.activity_listview, arrayList);

        listView = (ListView) findViewById(R.id.searchList);
        listView.setAdapter(adapter);

        //See details of appointment
        listView.setOnItemClickListener((parent, view, position, id) -> {

            appointmentAdaptor = new AppointmentAdaptor(getBaseContext(), -1, listArr);

            display(appointmentAdaptor.getItem(position) , view);

        });
    }

    // Show details of selected appointment
    public void display(Appointment appointment , View v){

        Toast.makeText(getBaseContext(),appointment.getTitle(), Toast.LENGTH_SHORT).show();

        LayoutInflater inflater = (LayoutInflater) Search.this
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        final View layout = inflater.inflate(R.layout.search_popup,
                (ViewGroup) findViewById(R.id.searchPoppup_screen));


        text_title = (TextView) layout.findViewById(R.id.searchTitle) ;
        text_time = (TextView) layout.findViewById(R.id.searchTime) ;
        text_details = (TextView) layout.findViewById(R.id.searchDetails) ;


        popupWindow = new PopupWindow(layout, 1000, 900 ,  true);
        popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);

        text_title.setText(appointment.getTitle());
        text_time.setText(appointment.getTime());
        text_details.setText(appointment.getDetails());

    }

    @Override
    public void onClick(View view) {

    }
    // Swap between portrait and landscape mode
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        // Checks the orientation of the screen
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
        }
    }
}