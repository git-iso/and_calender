package com.example.a3p97_scheduler;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.database.Cursor;
import android.net.Uri;

import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.Calendar;

// Create a new appointment
public class Create extends AppCompatActivity implements View.OnClickListener{

    // UI Features
    EditText titleET;
    TextView detailsTV, timeTV;
    Button btn_save, btn_contact, btn_time;

    // Database info
    DB dbHandler;
    private String date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);

        // Basic assignments
        Intent intent = getIntent();
        date = intent.getStringExtra("Date");
       // Toast.makeText(getBaseContext() , date , Toast.LENGTH_SHORT).show();

        titleET = (EditText) findViewById(R.id.titleEditText);
        timeTV = (TextView) findViewById(R.id.timeViewText);
        detailsTV  = (TextView) findViewById(R.id.detailsViewText);


        btn_save = (Button) findViewById(R.id.saveButton);

        // Add new appointment to database
        btn_save.setOnClickListener(view -> {

            String time = timeTV.getText().toString();
            String title = titleET.getText().toString();
            String details = detailsTV.getText().toString();

            if (TextUtils.isEmpty(time)){

                timeTV.setError("Please set a time for the appointment.");


            }else if (TextUtils.isEmpty(title)) {

                titleET.setError("Please set a title for the appointment.");


            }else if(TextUtils.isEmpty(details)) {

                detailsTV.setError("Please set a details for the appointment.");


            }else {

                Appointment appointment = new Appointment(date, time, title, details);
                int i = dbHandler.createAppointment(appointment);
                if (i == 1) {

                    errorDialog("Appointment " + title + " on " + date + " was created successfully.");
                    printDB();

                } else if (i == -1) {

                    errorDialog("Appointment "+ title +" already exists, please choose a different event title");
                }


            }


        });

        btn_contact = (Button) findViewById(R.id.btn_contact);

        //Get contact list
        btn_contact.setOnClickListener(view -> {

            Intent contactPickerIntent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_CONTACTS) ==
                    PackageManager.PERMISSION_GRANTED) {

                startActivityForResult(contactPickerIntent,1);

            } else if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.READ_CONTACTS)) {

                //showInContextUI(...);

            } else {


                requestPermissionLauncher.launch(
                        Manifest.permission.READ_CONTACTS);
            }
           // startActivityForResult(contactPickerIntent,1);

        });

        btn_time = (Button) findViewById(R.id.btn_time);

        // Show valid times for user to select
        btn_time.setOnClickListener(v -> {

            final Calendar c = Calendar.getInstance();

            int hour = c.get(Calendar.HOUR_OF_DAY);
            int minute = c.get(Calendar.MINUTE);


            TimePickerDialog timePickerDialog = new TimePickerDialog(Create.this,
                    (view, hourOfDay, minute1) -> {

                        String newminute = String.valueOf(minute1);

                        if (minute1 < 10){

                            newminute = "0" + minute1;

                        }
                        timeTV.setText(hourOfDay + ":" + newminute);
                    }, hour, minute, false);

            timePickerDialog.show();
        });


        dbHandler = new DB(this, null, null, 1);

    }


    private ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {

                } else {

                }
            });

    // Current DB entities
    public void printDB(){

        String dbString = dbHandler.databaseToString();
        //Toast.makeText(getBaseContext() , dbString , Toast.LENGTH_LONG).show();
        titleET.setText(""); timeTV.setText("");detailsTV.setText("");

    }

    // Contact handling
    @SuppressLint("Range")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case 1:
                if (resultCode == Activity.RESULT_OK) {
                    Uri contactData = data.getData();

                    Cursor cur = getContentResolver().query(contactData, null, null, null, null);
                    if (cur.getCount() > 0) {//

                        if (cur.moveToNext()) {

                            @SuppressLint("Range") String id = cur.getString(cur.getColumnIndex(ContactsContract.Contacts._ID));
                            String name = cur.getString(cur.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                            Log.e("Names", name);

                            if (Integer.parseInt(cur.getString(cur.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {

                                Cursor phones = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + id, null, null);

                                while (phones.moveToNext()) {

                                    // Get phone # from selected contact
                                    String phoneNumber = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                                    detailsTV.setText(phoneNumber);
                                    Log.e("Number", phoneNumber);
                                }

                                phones.close();

                            }

                        }
                    }

                    cur.close();
                }

                break;

        }
    }

    // Indicate invalid appointment creation
    public void errorDialog(String error)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(error);
        builder.setCancelable(true);

        builder.setPositiveButton(
                "OK",
                (dialog, id) -> dialog.dismiss());

        AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public void onClick(View view) {

    }

    // Swap between portrait and landscape mode
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        // Checks the orientation of the screen
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
        }
    }

}