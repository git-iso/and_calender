package com.example.a3p97_scheduler;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;

import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

// Move all the appointments on a day to another day
public class Move extends AppCompatActivity {

    // Database definitions
    DB DB;
    String date, changeType, popupDate;

    //UI definitions
    Button confirmBtn;
    TextView heading;
    ArrayAdapter adapter;
    ListView listView;
    List<Appointment> listArr;
    ArrayList<String> arrayList;
    PopupWindow popupWindow;
    Button moveBtn;
    CalendarView calendarView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_move);

        //Basic assignments
        Intent intent = getIntent();
        date = intent.getStringExtra("Date");
        changeType = intent.getStringExtra("Change Type");

        heading = (TextView) findViewById(R.id.heading);
        confirmBtn = (Button) findViewById(R.id.confirmButton);

        DB = new DB(this, null, null, 1);

        //Get all appointments to move
        listArr = DB.displayAppointments(date);

        arrayList = new ArrayList<>();

        for(int j=0 ; j<listArr.size() ; j++){

            arrayList.add(j+1 + ". " + listArr.get(j).getTime() + " " + listArr.get(j).getTitle() + " " + listArr.get(j).getDetails());

        }

        adapter = new ArrayAdapter<String>(this, R.layout.activity_listview, arrayList);

        listView = (ListView) findViewById(R.id.appointmentList);
        listView.setAdapter(adapter);

        //Select day to move appointment
        confirmBtn.setOnClickListener(v -> {

            if (!arrayList.isEmpty()) {
                moveAppointmentPopup(v);
            }

        });

    }

    //New day selector
    private void moveAppointmentPopup (View v) {

        try {

            LayoutInflater inflater = (LayoutInflater) Move.this
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            final View layout = inflater.inflate(R.layout.move_popup,
                    (ViewGroup) findViewById(R.id.movePopup_screen));


            popupWindow = new PopupWindow(layout, 1020, 1800 ,  true);
            popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);

            calendarView = (CalendarView) layout.findViewById(R.id.calendarViewPopup);
            calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {

                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                String dateSelected = simpleDateFormat.format(new GregorianCalendar(year, month, dayOfMonth).getTime());
                popupDate = dateSelected;

            });


            moveBtn = (Button) layout.findViewById(R.id.moveButton);
            moveBtn.setOnClickListener(v1 -> {

                try {

                    for (Appointment a: listArr) {


                        DB.moveAppointment(a, popupDate);

                    }

                    finish();
                    startActivity(getIntent());

                }catch (IndexOutOfBoundsException e){

                    //Toast.makeText(getBaseContext(), "Couldn't find the specified appointment in the database." , Toast.LENGTH_SHORT).show();

                }catch (Exception e){

                    //Toast.makeText(getBaseContext(), "Invalid input. Please try again with a valid number." , Toast.LENGTH_SHORT).show();
                }
                popupWindow.dismiss();

            });


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // Swap between portrait and landscape mode
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        // Checks the orientation of the screen
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
        }
    }
}