package com.example.a3p97_scheduler;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.PopupWindow;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

// Main screen of app
public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //Basic definitions
    Button btn_create, btn_delete, btn_move, btn_search;
    Button btn_deleteAll, btn_deleteSelected;
    CalendarView calendarView;
    PopupWindow popupWindow;

    //Database definitions
    DB DB;
    String date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Basic assignments
        DB = new DB(this, null, null, 1);


        btn_create = (Button) findViewById(R.id.btn_create);
        btn_create.setOnClickListener(this);


        btn_delete = (Button) findViewById(R.id.btn_delete);
        btn_delete.setOnClickListener(this);

        btn_move = (Button) findViewById(R.id.btn_move);
        btn_move.setOnClickListener(this);

        btn_search = (Button) findViewById(R.id.btn_search);
        btn_search.setOnClickListener(this);

        calendarView = (CalendarView) findViewById(R.id.ms_calendarView);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {

                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                String dateSelected = simpleDateFormat.format(new GregorianCalendar(year, month, dayOfMonth).getTime());
                date = dateSelected;


            }
        });

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String dateSelected = simpleDateFormat.format(new Date(calendarView.getDate()));
        date = dateSelected;

    }

    //Go to screen depending on button click
    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.btn_create: {

                Intent intent = new Intent(getBaseContext(), Create.class);
                intent.putExtra("Date", date); // format - dd/MM/yyyy
                startActivity(intent);
                break;

            }

            case R.id.btn_delete: {
                deleteAppointmentPopup(v);
                break;

            }

            case R.id.btn_move:{
                Intent intent = new Intent(getBaseContext() , Move.class);
                intent.putExtra("Date" , date ); // format - dd/MM/yyyy
                intent.putExtra("Change Type" , "Move" );
                startActivity(intent);
                break;

            }

            case R.id.btn_search: {

                Intent intent = new Intent(getBaseContext(), Search.class);
                intent.putExtra("Date", date);
                startActivity(intent);
                break;

            }


        }

    }

    //Show 2 potential delete options (one day or all days)
    private void deleteAppointmentPopup(View v) {

        try {

            LayoutInflater inflater = (LayoutInflater) MainActivity.this
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);


            final View layout = inflater.inflate(R.layout.delete_popup,
                    (ViewGroup) findViewById(R.id.delete_popup));


            popupWindow = new PopupWindow(layout, 1000, 900, true);
            popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);


            btn_deleteAll = (Button) layout.findViewById(R.id.btn_popup_deleteAll);
            btn_deleteAll.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(getBaseContext(), "Deleted all the appointments on " + date, Toast.LENGTH_LONG).show();
                    DB.deleteAppointments(date);
                    popupWindow.dismiss();
                }
            });


            btn_deleteSelected = (Button) layout.findViewById(R.id.btn_popup_deleteSelected);
            btn_deleteSelected.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    DB.clearTable("appointments");
                    popupWindow.dismiss();
                }
            });


        } catch (Exception e) {

        }

    }
}



