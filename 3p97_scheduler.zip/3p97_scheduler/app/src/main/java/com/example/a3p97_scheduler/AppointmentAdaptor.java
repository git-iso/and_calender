package com.example.a3p97_scheduler;

import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.util.List;

// Adapt appointment class to UI
public class AppointmentAdaptor extends ArrayAdapter<Appointment> {

    TextView titleTV , detailsTV;

    public AppointmentAdaptor(Context context, int textViewResourceId, List<Appointment> appointments){
        super(context, textViewResourceId, appointments);
    }

    // Format appointment for UI
    @Override
    public View getView(int position, View convertView,ViewGroup parent) {

        RelativeLayout row = (RelativeLayout)convertView;

        if(null == row){

            LayoutInflater inflater = (LayoutInflater)parent.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = (RelativeLayout)inflater.inflate(R.layout.list_row_appointment, null);
        }


        titleTV = (TextView)row.findViewById(R.id.titleTextView);
        detailsTV = (TextView)row.findViewById(R.id.detailsTextView);

        titleTV.setText(getItem(position).getTitle());
        detailsTV.setText(getItem(position).getDetails());

        return row;
    }
}